import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { SessionModule } from "./session/session.module";
import { SigninPageComponent } from "./signin-page/signin-page.component";
import { SignupPageComponent } from "./signup-page/signup-page.component";

@NgModule({
  declarations: [
    AppComponent,
    SigninPageComponent,
    SignupPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    SessionModule
  ],
  providers: [
    { provide: 'API_URL', useValue: 'https://api.backendless.com/A055A2AD-8F3A-3AC5-FF6D-CB7F6FC7FC00/538D19D8-06B4-A162-FFC3-3489A8D80300/' },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
